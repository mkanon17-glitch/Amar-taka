package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TransactionEntity::class, AppSettingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AmarTakaDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao

    companion object {
        @Volatile
        private var INSTANCE: AmarTakaDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AmarTakaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AmarTakaDatabase::class.java,
                    "amar_taka_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.transactionDao())
                    }
                }
            }

            suspend fun populateInitialData(dao: TransactionDao) {
                val now = System.currentTimeMillis()
                val oneDay = 86400000L

                // Default monthly budget: ৳35,000
                dao.setSetting(AppSettingEntity(key = "monthly_budget", value = "35000.0"))
                dao.setSetting(AppSettingEntity(key = "app_language", value = "bn"))

                val initialTransactions = listOf(
                    TransactionEntity(
                        title = "মাসিক বেতন (Salary)",
                        amount = 55000.0,
                        type = "INCOME",
                        categoryId = "salary",
                        walletId = "bank",
                        timestamp = now - (oneDay * 4),
                        note = "অফিস থেকে প্রেরিত বেতন"
                    ),
                    TransactionEntity(
                        title = "কাঁচাবাজার ও গ্রোসারি",
                        amount = 3850.0,
                        type = "EXPENSE",
                        categoryId = "food",
                        walletId = "cash",
                        timestamp = now - (oneDay * 3),
                        note = "মাছ, মাংস, চাল ও শাকসবজি"
                    ),
                    TransactionEntity(
                        title = "বাসাভাড়া প্রদান (House Rent)",
                        amount = 16000.0,
                        type = "EXPENSE",
                        categoryId = "rent",
                        walletId = "bank",
                        timestamp = now - (oneDay * 3),
                        note = "মাসিক ফ্ল্যাট ভাড়া"
                    ),
                    TransactionEntity(
                        title = "ফ্রিল্যান্স প্রজেক্ট পেমেন্ট",
                        amount = 12500.0,
                        type = "INCOME",
                        categoryId = "freelance",
                        walletId = "bkash",
                        timestamp = now - (oneDay * 2),
                        note = "মোবাইল অ্যাপ ডিজাইন প্রজেক্ট"
                    ),
                    TransactionEntity(
                        title = "মেট্রোরেল ও রিকশা ভাড়া",
                        amount = 260.0,
                        type = "EXPENSE",
                        categoryId = "transport",
                        walletId = "cash",
                        timestamp = now - (oneDay * 2),
                        note = "অফিস যাতায়াত"
                    ),
                    TransactionEntity(
                        title = "ডিপিডিসি বিদ্যুৎ বিল (bKash)",
                        amount = 1850.0,
                        type = "EXPENSE",
                        categoryId = "bills",
                        walletId = "bkash",
                        timestamp = now - (oneDay * 1),
                        note = "গত মাসের বিদ্যুৎ বিল পরিশোধ"
                    ),
                    TransactionEntity(
                        title = "রেস্তোরাঁ ও সান্ধ্যকালীন নাস্তা",
                        amount = 740.0,
                        type = "EXPENSE",
                        categoryId = "food",
                        walletId = "nagad",
                        timestamp = now - 3600000L * 5,
                        note = "বন্ধুদের সাথে কাচ্চি ও বোরহানি"
                    ),
                    TransactionEntity(
                        title = "ফার্মেসি ও ভিটামিন ওষুধ",
                        amount = 620.0,
                        type = "EXPENSE",
                        categoryId = "health",
                        walletId = "cash",
                        timestamp = now - 3600000L * 2,
                        note = "প্রেসক্রিপশন ওষুধ"
                    )
                )

                dao.insertTransactions(initialTransactions)
            }
        }
    }
}
