package com.example.data

import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val dao: TransactionDao) {

    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        return dao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) {
        dao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        dao.deleteTransaction(transaction)
    }

    suspend fun deleteTransactionById(id: Long) {
        dao.deleteTransactionById(id)
    }

    fun getSetting(key: String): Flow<AppSettingEntity?> {
        return dao.getSetting(key)
    }

    suspend fun setSetting(key: String, value: String) {
        dao.setSetting(AppSettingEntity(key = key, value = value))
    }

    suspend fun populateSampleDataIfEmpty() {
        if (dao.getCount() == 0) {
            val now = System.currentTimeMillis()
            val oneDay = 86400000L

            dao.setSetting(AppSettingEntity(key = "monthly_budget", value = "35000.0"))
            dao.setSetting(AppSettingEntity(key = "app_language", value = "bn"))

            val sampleList = listOf(
                TransactionEntity(
                    title = "মাসিক বেতন (Salary)",
                    amount = 55000.0,
                    type = "INCOME",
                    categoryId = "salary",
                    walletId = "bank",
                    timestamp = now - (oneDay * 4),
                    note = "অফিস থেকে প্রেরিত বেতন"
                ),
                TransactionEntity(
                    title = "কাঁচাবাজার ও গ্রোসারি",
                    amount = 3850.0,
                    type = "EXPENSE",
                    categoryId = "food",
                    walletId = "cash",
                    timestamp = now - (oneDay * 3),
                    note = "মাছ, মাংস, চাল ও শাকসবজি"
                ),
                TransactionEntity(
                    title = "বাসাভাড়া প্রদান (House Rent)",
                    amount = 16000.0,
                    type = "EXPENSE",
                    categoryId = "rent",
                    walletId = "bank",
                    timestamp = now - (oneDay * 3),
                    note = "মাসিক ফ্ল্যাট ভাড়া"
                ),
                TransactionEntity(
                    title = "ফ্রিল্যান্স প্রজেক্ট পেমেন্ট",
                    amount = 12500.0,
                    type = "INCOME",
                    categoryId = "freelance",
                    walletId = "bkash",
                    timestamp = now - (oneDay * 2),
                    note = "মোবাইল অ্যাপ ডিজাইন প্রজেক্ট"
                ),
                TransactionEntity(
                    title = "মেট্রোরেল ও রিকশা ভাড়া",
                    amount = 260.0,
                    type = "EXPENSE",
                    categoryId = "transport",
                    walletId = "cash",
                    timestamp = now - (oneDay * 2),
                    note = "অফিস যাতায়াত"
                ),
                TransactionEntity(
                    title = "ডিপিডিসি বিদ্যুৎ বিল (bKash)",
                    amount = 1850.0,
                    type = "EXPENSE",
                    categoryId = "bills",
                    walletId = "bkash",
                    timestamp = now - (oneDay * 1),
                    note = "গত মাসের বিদ্যুৎ বিল পরিশোধ"
                ),
                TransactionEntity(
                    title = "রেস্তোরাঁ ও সান্ধ্যকালীন নাস্তা",
                    amount = 740.0,
                    type = "EXPENSE",
                    categoryId = "food",
                    walletId = "nagad",
                    timestamp = now - 3600000L * 5,
                    note = "বন্ধুদের সাথে কাচ্চি ও বোরহানি"
                ),
                TransactionEntity(
                    title = "ফার্মেসি ও ভিটামিন ওষুধ",
                    amount = 620.0,
                    type = "EXPENSE",
                    categoryId = "health",
                    walletId = "cash",
                    timestamp = now - 3600000L * 2,
                    note = "প্রেসক্রিপশন ওষুধ"
                )
            )
            dao.insertTransactions(sampleList)
        }
    }
}
