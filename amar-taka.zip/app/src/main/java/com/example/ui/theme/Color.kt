package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val EmeraldPrimary = Color(0xFF0A6847)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD4EEDF)
val EmeraldOnPrimaryContainer = Color(0xFF002113)

val TealSecondary = Color(0xFF16796F)
val TealOnSecondary = Color(0xFFFFFFFF)
val TealSecondaryContainer = Color(0xFFC7EBE6)
val TealOnSecondaryContainer = Color(0xFF00201D)

val GoldTertiary = Color(0xFFE5A00D)
val GoldTertiaryContainer = Color(0xFFFFF0D4)
val GoldOnTertiaryContainer = Color(0xFF422800)

val LightBackground = Color(0xFFF7FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9F0EC)
val LightOutline = Color(0xFFCFD9D3)

// Dark Palette
val EmeraldPrimaryDark = Color(0xFF5DDBA3)
val EmeraldOnPrimaryDark = Color(0xFF003822)
val EmeraldPrimaryContainerDark = Color(0xFF005234)

val TealSecondaryDark = Color(0xFF7DD5C9)
val TealOnSecondaryDark = Color(0xFF003732)
val TealSecondaryContainerDark = Color(0xFF005049)

val GoldTertiaryDark = Color(0xFFFFD580)
val DarkBackground = Color(0xFF0D1512)
val DarkSurface = Color(0xFF141E1A)
val DarkSurfaceVariant = Color(0xFF1E2C26)
val DarkOutline = Color(0xFF33453E)

// Semantic Finance Colors
val IncomeGreen = Color(0xFF2E7D32)
val ExpenseRed = Color(0xFFD32F2F)
val WarningOrange = Color(0xFFED6C02)
val BkashPink = Color(0xFFE2136E)
val NagadOrange = Color(0xFFE65100)
val BankBlue = Color(0xFF1565C0)
val RocketPurple = Color(0xFF7B1FA2)

