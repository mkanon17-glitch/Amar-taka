package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.model.Category
import com.example.model.CurrencyFormatter
import com.example.model.Language
import com.example.model.TransactionType
import com.example.model.WalletAccount
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTransactionSheet(
    transaction: TransactionEntity?,
    language: Language,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        title: String,
        amount: Double,
        type: TransactionType,
        category: Category,
        wallet: WalletAccount,
        timestamp: Long,
        note: String
    ) -> Unit,
    onDelete: ((TransactionEntity) -> Unit)? = null
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val isEditing = transaction != null
    val initialType = if (transaction?.type.equals("INCOME", ignoreCase = true)) {
        TransactionType.INCOME
    } else {
        TransactionType.EXPENSE
    }

    var selectedType by remember { mutableStateOf(initialType) }
    var title by remember { mutableStateOf(transaction?.title ?: "") }
    var amountText by remember { mutableStateOf(transaction?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var selectedCategory by remember {
        mutableStateOf(
            if (transaction != null) Category.fromId(transaction.categoryId)
            else if (initialType == TransactionType.INCOME) Category.SALARY else Category.FOOD
        )
    }
    var selectedWallet by remember {
        mutableStateOf(
            if (transaction != null) WalletAccount.fromId(transaction.walletId)
            else WalletAccount.CASH
        )
    }
    var note by remember { mutableStateOf(transaction?.note ?: "") }
    var timestamp by remember { mutableLongStateOf(transaction?.timestamp ?: System.currentTimeMillis()) }

    var isAmountError by remember { mutableStateOf(false) }

    val categories = Category.getCategoriesForType(selectedType)

    // Quick Bangladesh title suggestions
    val titleSuggestions = if (selectedType == TransactionType.EXPENSE) {
        listOf("কাঁচাবাজার", "সকালের নাস্তা", "রিকশা ও বাস ভাড়া", "বিদ্যুৎ বিল", "ওষুধ", "কেনাকাটা")
    } else {
        listOf("মাসিক বেতন", "ফ্রিল্যান্স পেমেন্ট", "ব্যবসার মুনাফা", "বোনাস", "উপহার")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("add_edit_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEditing) {
                        if (language == Language.BN) "হিসাব সম্পাদনা করুন" else "Edit Transaction"
                    } else {
                        if (language == Language.BN) "নতুন হিসাব যোগ করুন" else "New Transaction"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Income / Expense Toggle Segment
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("type_segmented_row")
            ) {
                TransactionType.entries.forEachIndexed { index, type ->
                    val isSelected = selectedType == type
                    val activeColor = if (type == TransactionType.INCOME) IncomeGreen else ExpenseRed

                    SegmentedButton(
                        selected = isSelected,
                        onClick = {
                            selectedType = type
                            selectedCategory = Category.getCategoriesForType(type).first()
                        },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = TransactionType.entries.size),
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = activeColor.copy(alpha = 0.15f),
                            activeContentColor = activeColor
                        )
                    ) {
                        Text(
                            text = if (language == Language.BN) type.labelBn else type.labelEn,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Amount Input
            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    isAmountError = false
                },
                label = { Text(if (language == Language.BN) "টাকার পরিমাণ (Amount)" else "Amount") },
                prefix = {
                    Text(
                        text = "৳ ",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedType == TransactionType.INCOME) IncomeGreen else ExpenseRed
                    )
                },
                placeholder = { Text("0") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                isError = isAmountError,
                supportingText = if (isAmountError) {
                    { Text(if (language == Language.BN) "সঠিক পরিমাণ লিখুন" else "Please enter a valid amount") }
                } else null,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_input")
            )

            // Preset Amount Chips (+100, +500, +1000, +5000)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val presets = listOf(100, 500, 1000, 5000)
                presets.forEach { preset ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val cur = amountText.toDoubleOrNull() ?: 0.0
                                amountText = (cur + preset).toInt().toString()
                                isAmountError = false
                            }
                    ) {
                        Text(
                            text = "+${CurrencyFormatter.formatAmount(preset.toDouble(), language, showSymbol = false)}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Category Selector
            Text(
                text = if (language == Language.BN) "ক্যাটাগরি নির্বাচন করুন" else "Select Category",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                modifier = Modifier.testTag("category_selector_row")
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedCategory = cat }
                            .then(
                                if (isSelected) Modifier.border(
                                    width = 2.dp,
                                    color = cat.color,
                                    shape = RoundedCornerShape(12.dp)
                                ) else Modifier
                            ),
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) cat.color.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = null,
                                tint = if (isSelected) cat.color else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (language == Language.BN) cat.nameBn else cat.nameEn,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) cat.color else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Wallet Selector
            Text(
                text = if (language == Language.BN) "টাকা পরিশোধ / জমা মাধ্যম" else "Payment Method / Wallet",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WalletAccount.entries.forEach { wallet ->
                    val isSelected = selectedWallet == wallet
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedWallet = wallet }
                            .then(
                                if (isSelected) Modifier.border(
                                    width = 2.dp,
                                    color = wallet.brandColor,
                                    shape = RoundedCornerShape(12.dp)
                                ) else Modifier
                            ),
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) wallet.brandColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = wallet.icon,
                                contentDescription = null,
                                tint = if (isSelected) wallet.brandColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (language == Language.BN) wallet.nameBn else wallet.nameEn,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) wallet.brandColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title & Suggestions
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(if (language == Language.BN) "বিবরণ বা শিরোনাম (Title)" else "Title / Description") },
                placeholder = {
                    Text(if (language == Language.BN) selectedCategory.nameBn else selectedCategory.nameEn)
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("title_input")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Quick suggestion chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                items(titleSuggestions) { suggestion ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { title = suggestion }
                    ) {
                        Text(
                            text = suggestion,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Additional Note
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text(if (language == Language.BN) "অতিরিক্ত নোট (Optional Note)" else "Note (Optional)") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_input")
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Save & Delete Buttons
            Button(
                onClick = {
                    val parsedAmount = amountText.toDoubleOrNull()
                    if (parsedAmount == null || parsedAmount <= 0) {
                        isAmountError = true
                    } else {
                        onSave(
                            transaction?.id ?: 0L,
                            title,
                            parsedAmount,
                            selectedType,
                            selectedCategory,
                            selectedWallet,
                            timestamp,
                            note
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_transaction_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedType == TransactionType.INCOME) IncomeGreen else MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    text = if (isEditing) {
                        if (language == Language.BN) "আপডেট সংরক্ষণ করুন" else "Save Changes"
                    } else {
                        if (language == Language.BN) "হিসাব সংরক্ষণ করুন" else "Save Transaction"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isEditing && onDelete != null && transaction != null) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onDelete(transaction) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("delete_transaction_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = ExpenseRed
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == Language.BN) "হিসাবটি মুছে ফেলুন" else "Delete Transaction",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
