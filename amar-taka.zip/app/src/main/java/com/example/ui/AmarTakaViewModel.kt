package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AmarTakaDatabase
import com.example.data.TransactionEntity
import com.example.data.TransactionRepository
import com.example.model.Category
import com.example.model.DateFilter
import com.example.model.Language
import com.example.model.TransactionType
import com.example.model.WalletAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class AmarTakaUiState(
    val transactions: List<TransactionEntity> = emptyList(),
    val filteredTransactions: List<TransactionEntity> = emptyList(),
    val totalBalance: Double = 0.0,
    val monthlyIncome: Double = 0.0,
    val monthlyExpense: Double = 0.0,
    val monthlySavings: Double = 0.0,
    val monthlyBudget: Double = 35000.0,
    val budgetProgress: Float = 0f,
    val walletBalances: Map<WalletAccount, Double> = emptyMap(),
    val categoryBreakdown: List<CategoryExpenseShare> = emptyList(),
    val language: Language = Language.BN,
    val dateFilter: DateFilter = DateFilter.THIS_MONTH,
    val typeFilter: TransactionType? = null,
    val walletFilter: WalletAccount? = null,
    val searchQuery: String = "",
    val isAddEditSheetOpen: Boolean = false,
    val editingTransaction: TransactionEntity? = null,
    val isBudgetDialogOpen: Boolean = false
)

data class CategoryExpenseShare(
    val category: Category,
    val amount: Double,
    val percentage: Float
)

class AmarTakaViewModel(
    application: Application,
    private val repository: TransactionRepository
) : AndroidViewModel(application) {

    private val _language = MutableStateFlow(Language.BN)
    private val _monthlyBudget = MutableStateFlow(35000.0)
    private val _dateFilter = MutableStateFlow(DateFilter.THIS_MONTH)
    private val _typeFilter = MutableStateFlow<TransactionType?>(null)
    private val _walletFilter = MutableStateFlow<WalletAccount?>(null)
    private val _searchQuery = MutableStateFlow("")

    private val _isAddEditSheetOpen = MutableStateFlow(false)
    private val _editingTransaction = MutableStateFlow<TransactionEntity?>(null)
    private val _isBudgetDialogOpen = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            repository.populateSampleDataIfEmpty()
        }
        viewModelScope.launch {
            repository.getSetting("monthly_budget").collect { setting ->
                setting?.value?.toDoubleOrNull()?.let {
                    _monthlyBudget.value = it
                }
            }
        }
        viewModelScope.launch {
            repository.getSetting("app_language").collect { setting ->
                if (setting?.value == "en") {
                    _language.value = Language.EN
                } else if (setting?.value == "bn") {
                    _language.value = Language.BN
                }
            }
        }
    }

    private val coreDataFlow = combine(
        repository.allTransactions,
        _language,
        _monthlyBudget
    ) { allTx, lang, budget ->
        Triple(allTx, lang, budget)
    }

    private val filtersFlow = combine(
        _dateFilter,
        _typeFilter,
        _walletFilter
    ) { dFilter, tFilter, wFilter ->
        Triple(dFilter, tFilter, wFilter)
    }

    private val uiControlsFlow = combine(
        _searchQuery,
        _isAddEditSheetOpen,
        _editingTransaction,
        _isBudgetDialogOpen
    ) { q, sheetOpen, editingTx, bDialogOpen ->
        StateBundle2(q, sheetOpen, editingTx, bDialogOpen)
    }

    val uiState: StateFlow<AmarTakaUiState> = combine(
        coreDataFlow,
        filtersFlow,
        uiControlsFlow
    ) { (allTx, lang, budget), (dFilter, tFilter, wFilter), controls ->
        buildUiState(
            allTx = allTx,
            lang = lang,
            budget = budget,
            dFilter = dFilter,
            tFilter = tFilter,
            wFilter = wFilter,
            search = controls.search,
            sheetOpen = controls.sheetOpen,
            editingTx = controls.editingTx,
            bDialogOpen = controls.bDialogOpen
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AmarTakaUiState()
    )

    private fun buildUiState(
        allTx: List<TransactionEntity>,
        lang: Language,
        budget: Double,
        dFilter: DateFilter,
        tFilter: TransactionType?,
        wFilter: WalletAccount?,
        search: String,
        sheetOpen: Boolean,
        editingTx: TransactionEntity?,
        bDialogOpen: Boolean
    ): AmarTakaUiState {
        var totalBal = 0.0
        val walletMap = mutableMapOf<WalletAccount, Double>()
        WalletAccount.entries.forEach { walletMap[it] = 0.0 }

        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)
        val currentWeek = calendar.get(Calendar.WEEK_OF_YEAR)

        var mIncome = 0.0
        var mExpense = 0.0

        val categoryExpenseMap = mutableMapOf<Category, Double>()

        allTx.forEach { tx ->
            val isIncome = tx.type.equals("INCOME", ignoreCase = true)
            val wallet = WalletAccount.fromId(tx.walletId)

            if (isIncome) {
                totalBal += tx.amount
                walletMap[wallet] = (walletMap[wallet] ?: 0.0) + tx.amount
            } else {
                totalBal -= tx.amount
                walletMap[wallet] = (walletMap[wallet] ?: 0.0) - tx.amount
            }

            calendar.timeInMillis = tx.timestamp
            val txMonth = calendar.get(Calendar.MONTH)
            val txYear = calendar.get(Calendar.YEAR)

            if (txMonth == currentMonth && txYear == currentYear) {
                if (isIncome) {
                    mIncome += tx.amount
                } else {
                    mExpense += tx.amount
                    val cat = Category.fromId(tx.categoryId)
                    categoryExpenseMap[cat] = (categoryExpenseMap[cat] ?: 0.0) + tx.amount
                }
            }
        }

        val categoryShares = if (mExpense > 0) {
            categoryExpenseMap.map { (cat, amt) ->
                CategoryExpenseShare(
                    category = cat,
                    amount = amt,
                    percentage = (amt / mExpense).toFloat()
                )
            }.sortedByDescending { it.amount }
        } else {
            emptyList()
        }

        // Apply filters for the transaction list
        val filtered = allTx.filter { tx ->
            // Date filter
            val dateMatches = when (dFilter) {
                DateFilter.THIS_MONTH -> {
                    calendar.timeInMillis = tx.timestamp
                    calendar.get(Calendar.MONTH) == currentMonth && calendar.get(Calendar.YEAR) == currentYear
                }
                DateFilter.THIS_WEEK -> {
                    calendar.timeInMillis = tx.timestamp
                    calendar.get(Calendar.WEEK_OF_YEAR) == currentWeek && calendar.get(Calendar.YEAR) == currentYear
                }
                DateFilter.ALL -> true
            }

            // Type filter
            val typeMatches = when (tFilter) {
                null -> true
                TransactionType.EXPENSE -> tx.type.equals("EXPENSE", ignoreCase = true)
                TransactionType.INCOME -> tx.type.equals("INCOME", ignoreCase = true)
            }

            // Wallet filter
            val walletMatches = when (wFilter) {
                null -> true
                else -> tx.walletId.equals(wFilter.id, ignoreCase = true)
            }

            // Search query
            val searchMatches = if (search.isBlank()) true else {
                val cat = Category.fromId(tx.categoryId)
                val w = WalletAccount.fromId(tx.walletId)
                tx.title.contains(search, ignoreCase = true) ||
                        tx.note.contains(search, ignoreCase = true) ||
                        cat.nameEn.contains(search, ignoreCase = true) ||
                        cat.nameBn.contains(search, ignoreCase = true) ||
                        w.nameEn.contains(search, ignoreCase = true) ||
                        w.nameBn.contains(search, ignoreCase = true)
            }

            dateMatches && typeMatches && walletMatches && searchMatches
        }

        val progress = if (budget > 0) (mExpense / budget).toFloat().coerceIn(0f, 1.5f) else 0f

        return AmarTakaUiState(
            transactions = allTx,
            filteredTransactions = filtered,
            totalBalance = totalBal,
            monthlyIncome = mIncome,
            monthlyExpense = mExpense,
            monthlySavings = mIncome - mExpense,
            monthlyBudget = budget,
            budgetProgress = progress,
            walletBalances = walletMap,
            categoryBreakdown = categoryShares,
            language = lang,
            dateFilter = dFilter,
            typeFilter = tFilter,
            walletFilter = wFilter,
            searchQuery = search,
            isAddEditSheetOpen = sheetOpen,
            editingTransaction = editingTx,
            isBudgetDialogOpen = bDialogOpen
        )
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
        viewModelScope.launch {
            repository.setSetting("app_language", lang.code)
        }
    }

    fun toggleLanguage() {
        val next = if (_language.value == Language.BN) Language.EN else Language.BN
        setLanguage(next)
    }

    fun setDateFilter(filter: DateFilter) {
        _dateFilter.value = filter
    }

    fun setTypeFilter(type: TransactionType?) {
        _typeFilter.value = type
    }

    fun setWalletFilter(wallet: WalletAccount?) {
        _walletFilter.value = wallet
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openAddSheet() {
        _editingTransaction.value = null
        _isAddEditSheetOpen.value = true
    }

    fun openEditSheet(transaction: TransactionEntity) {
        _editingTransaction.value = transaction
        _isAddEditSheetOpen.value = true
    }

    fun closeSheet() {
        _isAddEditSheetOpen.value = false
        _editingTransaction.value = null
    }

    fun openBudgetDialog() {
        _isBudgetDialogOpen.value = true
    }

    fun closeBudgetDialog() {
        _isBudgetDialogOpen.value = false
    }

    fun setBudget(newBudget: Double) {
        if (newBudget > 0) {
            _monthlyBudget.value = newBudget
            viewModelScope.launch {
                repository.setSetting("monthly_budget", newBudget.toString())
            }
        }
        closeBudgetDialog()
    }

    fun saveTransaction(
        id: Long = 0,
        title: String,
        amount: Double,
        type: TransactionType,
        category: Category,
        wallet: WalletAccount,
        timestamp: Long,
        note: String
    ) {
        viewModelScope.launch {
            val tx = TransactionEntity(
                id = id,
                title = title.ifBlank {
                    if (_language.value == Language.BN) category.nameBn else category.nameEn
                },
                amount = amount,
                type = type.name,
                categoryId = category.id,
                walletId = wallet.id,
                timestamp = timestamp,
                note = note
            )
            if (id == 0L) {
                repository.insertTransaction(tx)
            } else {
                repository.updateTransaction(tx)
            }
            closeSheet()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            if (_editingTransaction.value?.id == transaction.id) {
                closeSheet()
            }
        }
    }

    private data class StateBundle2(
        val search: String,
        val sheetOpen: Boolean,
        val editingTx: TransactionEntity?,
        val bDialogOpen: Boolean
    )

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AmarTakaDatabase.getDatabase(
                        application,
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO)
                    )
                    val repository = TransactionRepository(db.transactionDao())
                    return AmarTakaViewModel(application, repository) as T
                }
            }
    }
}
