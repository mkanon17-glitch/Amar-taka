package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.CurrencyFormatter
import com.example.model.DateFilter
import com.example.model.Language
import com.example.model.TransactionType
import com.example.ui.components.AddEditTransactionSheet
import com.example.ui.components.CategoryBreakdownCard
import com.example.ui.components.SetBudgetDialog
import com.example.ui.components.TopOverviewCard
import com.example.ui.components.TransactionItemCard
import com.example.ui.components.WalletCardsRow
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmarTakaScreen(
    viewModel: AmarTakaViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lang = uiState.language

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = "৳",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Column {
                            Text(
                                text = if (lang == Language.BN) "আমার টাকা" else "Amar Taka",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (lang == Language.BN) "দৈনিক আয়-ব্যয়ের নির্ভুল হিসাব" else "Personal Finance & Budget",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    // Language Toggle Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .testTag("language_toggle_button")
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { viewModel.toggleLanguage() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (lang == Language.BN) "English" else "বাংলা",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.openAddSheet() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Transaction",
                        modifier = Modifier.size(24.dp)
                    )
                },
                text = {
                    Text(
                        text = if (lang == Language.BN) "হিসাব যোগ করুন" else "Add Transaction",
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .testTag("add_transaction_fab")
                    .navigationBarsPadding()
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // 1. Top Overview Hero Card
            item {
                TopOverviewCard(
                    totalBalance = uiState.totalBalance,
                    monthlyIncome = uiState.monthlyIncome,
                    monthlyExpense = uiState.monthlyExpense,
                    monthlySavings = uiState.monthlySavings,
                    monthlyBudget = uiState.monthlyBudget,
                    budgetProgress = uiState.budgetProgress,
                    language = lang,
                    onEditBudgetClick = { viewModel.openBudgetDialog() },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            // 2. Wallets Row
            item {
                Spacer(modifier = Modifier.height(8.dp))
                WalletCardsRow(
                    walletBalances = uiState.walletBalances,
                    selectedWallet = uiState.walletFilter,
                    language = lang,
                    onWalletSelect = { viewModel.setWalletFilter(it) }
                )
            }

            // 3. Category Breakdown (if expenses exist)
            if (uiState.categoryBreakdown.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    CategoryBreakdownCard(
                        categoryShares = uiState.categoryBreakdown,
                        language = lang,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // 4. Filters & Search Section
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    // Search Bar
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = {
                            Text(if (lang == Language.BN) "হিসাব বা ক্যাটাগরি খুঁজুন..." else "Search transactions...")
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        trailingIcon = {
                            if (uiState.searchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                            focusedContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_text_field")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Date & Type Filter Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Date filters
                        items(DateFilter.entries) { dFilter ->
                            val isSelected = uiState.dateFilter == dFilter
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setDateFilter(dFilter) },
                                label = {
                                    Text(if (lang == Language.BN) dFilter.labelBn else dFilter.labelEn)
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }

                        // Type filter: All
                        item {
                            FilterChip(
                                selected = uiState.typeFilter == null,
                                onClick = { viewModel.setTypeFilter(null) },
                                label = {
                                    Text(if (lang == Language.BN) "সব ধরন" else "All Types")
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }

                        // Type filter: Expense
                        item {
                            FilterChip(
                                selected = uiState.typeFilter == TransactionType.EXPENSE,
                                onClick = { viewModel.setTypeFilter(TransactionType.EXPENSE) },
                                label = {
                                    Text(if (lang == Language.BN) "শুধুমাত্র ব্যয়" else "Expenses")
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ExpenseRed.copy(alpha = 0.15f),
                                    selectedLabelColor = ExpenseRed
                                )
                            )
                        }

                        // Type filter: Income
                        item {
                            FilterChip(
                                selected = uiState.typeFilter == TransactionType.INCOME,
                                onClick = { viewModel.setTypeFilter(TransactionType.INCOME) },
                                label = {
                                    Text(if (lang == Language.BN) "শুধুমাত্র আয়" else "Income")
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IncomeGreen.copy(alpha = 0.15f),
                                    selectedLabelColor = IncomeGreen
                                )
                            )
                        }
                    }
                }
            }

            // 5. Transaction List Header
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == Language.BN) "লেনদেন তালিকা" else "Transaction Records",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val count = uiState.filteredTransactions.size
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = if (lang == Language.BN) "${CurrencyFormatter.toBengaliNumber(count)} টি" else "$count entries",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 6. Transactions or Empty State
            if (uiState.filteredTransactions.isEmpty()) {
                item {
                    EmptyTransactionView(
                        language = lang,
                        hasFilters = uiState.searchQuery.isNotBlank() || uiState.walletFilter != null || uiState.typeFilter != null,
                        onResetFilters = {
                            viewModel.setSearchQuery("")
                            viewModel.setWalletFilter(null)
                            viewModel.setTypeFilter(null)
                            viewModel.setDateFilter(DateFilter.ALL)
                        },
                        onAddNew = { viewModel.openAddSheet() }
                    )
                }
            } else {
                items(
                    items = uiState.filteredTransactions,
                    key = { it.id }
                ) { transaction ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        TransactionItemCard(
                            transaction = transaction,
                            language = lang,
                            onClick = { viewModel.openEditSheet(transaction) },
                            onDeleteClick = { viewModel.deleteTransaction(transaction) }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Transaction Sheet
    if (uiState.isAddEditSheetOpen) {
        AddEditTransactionSheet(
            transaction = uiState.editingTransaction,
            language = lang,
            onDismiss = { viewModel.closeSheet() },
            onSave = { id, title, amount, type, category, wallet, timestamp, note ->
                viewModel.saveTransaction(id, title, amount, type, category, wallet, timestamp, note)
            },
            onDelete = { tx ->
                viewModel.deleteTransaction(tx)
            }
        )
    }

    // Set Monthly Budget Dialog
    if (uiState.isBudgetDialogOpen) {
        SetBudgetDialog(
            currentBudget = uiState.monthlyBudget,
            language = lang,
            onDismiss = { viewModel.closeBudgetDialog() },
            onConfirm = { newBudget ->
                viewModel.setBudget(newBudget)
            }
        )
    }
}

@Composable
private fun EmptyTransactionView(
    language: Language,
    hasFilters: Boolean,
    onResetFilters: () -> Unit,
    onAddNew: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.ReceiptLong,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = if (hasFilters) {
                if (language == Language.BN) "কোনো লেনদেন পাওয়া যায়নি" else "No matching transactions"
            } else {
                if (language == Language.BN) "এখনো কোনো হিসাব যোগ করা হয়নি" else "No transactions recorded yet"
            },
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (hasFilters) {
                if (language == Language.BN) "ফিল্টার পরিবর্তন করুন বা রিসেট বাটনে চাপুন" else "Try adjusting or clearing your search filters"
            } else {
                if (language == Language.BN) "নিচের বাটনে চাপ দিয়ে আপনার প্রথম আয় বা ব্যয়ের হিসাব যোগ করুন" else "Tap below to add your first income or expense"
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (hasFilters) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onResetFilters() }
            ) {
                Text(
                    text = if (language == Language.BN) "ফিল্টার রিসেট করুন" else "Reset Filters",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        } else {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onAddNew() }
            ) {
                Text(
                    text = if (language == Language.BN) "+ নতুন হিসাব যোগ করুন" else "+ Add New Entry",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}
