package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LaptopMac
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import java.text.NumberFormat
import java.util.Locale

enum class TransactionType(val labelEn: String, val labelBn: String) {
    EXPENSE("Expense", "ব্যয়"),
    INCOME("Income", "আয়")
}

enum class WalletAccount(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val brandColor: Color,
    val icon: ImageVector
) {
    CASH("cash", "Cash", "নগদ টাকা", Color(0xFF2E7D32), Icons.Default.Payments),
    BKASH("bkash", "bKash", "বিকাশ", Color(0xFFE2136E), Icons.Default.AccountBalanceWallet),
    NAGAD("nagad", "Nagad", "নগদ একাউন্ট", Color(0xFFE65100), Icons.Default.AccountBalanceWallet),
    BANK("bank", "Bank", "ব্যাংক", Color(0xFF1565C0), Icons.Default.AccountBalance),
    ROCKET("rocket", "Rocket", "রকেট", Color(0xFF7B1FA2), Icons.Default.AccountBalanceWallet);

    companion object {
        fun fromId(id: String): WalletAccount {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: CASH
        }
    }
}

enum class Category(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val type: TransactionType,
    val icon: ImageVector,
    val color: Color
) {
    // Expenses
    FOOD("food", "Food & Bazaar", "খাবার ও কাঁচাবাজার", TransactionType.EXPENSE, Icons.Default.Restaurant, Color(0xFFE53935)),
    RENT("rent", "Rent & Housing", "বাসাভাড়া ও ঘরখরচ", TransactionType.EXPENSE, Icons.Default.Home, Color(0xFF8E24AA)),
    BILLS("bills", "Bills & Utilities", "বিদ্যুৎ ও গ্যাস বিল", TransactionType.EXPENSE, Icons.Default.ElectricBolt, Color(0xFFFB8C00)),
    TRANSPORT("transport", "Transport", "যাতায়াত ও ভাড়া", TransactionType.EXPENSE, Icons.Default.DirectionsBus, Color(0xFF00ACC1)),
    SHOPPING("shopping", "Shopping", "কেনাকাটা", TransactionType.EXPENSE, Icons.Default.ShoppingBag, Color(0xFFD81B60)),
    HEALTH("health", "Health & Medicine", "চিকিৎসা ও ওষুধ", TransactionType.EXPENSE, Icons.Default.LocalHospital, Color(0xFF43A047)),
    EDUCATION("education", "Education", "শিক্ষা ও বই", TransactionType.EXPENSE, Icons.Default.School, Color(0xFF3949AB)),
    ENTERTAINMENT("entertainment", "Entertainment", "বিনোদন ও আড্ডা", TransactionType.EXPENSE, Icons.Default.SportsEsports, Color(0xFF7E57C2)),
    GIFT_FAMILY("gift_family", "Family & Gifts", "পরিবার ও উপহার", TransactionType.EXPENSE, Icons.Default.CardGiftcard, Color(0xFF00897B)),
    OTHER_EXPENSE("other_exp", "Other Expense", "অন্যান্য ব্যয়", TransactionType.EXPENSE, Icons.Default.MoreHoriz, Color(0xFF757575)),

    // Income
    SALARY("salary", "Salary", "মাসিক বেতন", TransactionType.INCOME, Icons.Default.Payments, Color(0xFF2E7D32)),
    BUSINESS("business", "Business", "ব্যবসা ও বাণিজ্য", TransactionType.INCOME, Icons.Default.Storefront, Color(0xFF1976D2)),
    FREELANCE("freelance", "Freelance", "ফ্রিল্যান্সিং", TransactionType.INCOME, Icons.Default.LaptopMac, Color(0xFF00838F)),
    INVESTMENT("investment", "Investment", "বিনিয়োগ মুনাফা", TransactionType.INCOME, Icons.Default.TrendingUp, Color(0xFF689F38)),
    BONUS("bonus", "Bonus & Gift", "বোনাস ও উপহার", TransactionType.INCOME, Icons.Default.Redeem, Color(0xFFEF6C00)),
    OTHER_INCOME("other_inc", "Other Income", "অন্যান্য আয়", TransactionType.INCOME, Icons.Default.AccountBalanceWallet, Color(0xFF5D4037));

    companion object {
        fun fromId(id: String): Category {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: OTHER_EXPENSE
        }

        fun getCategoriesForType(type: TransactionType): List<Category> {
            return entries.filter { it.type == type }
        }
    }
}

enum class DateFilter(val labelEn: String, val labelBn: String) {
    THIS_MONTH("This Month", "এই মাস"),
    THIS_WEEK("This Week", "এই সপ্তাহ"),
    ALL("All Time", "সব সময়")
}

enum class Language(val code: String, val label: String) {
    BN("bn", "বাংলা"),
    EN("en", "English")
}

object CurrencyFormatter {
    private val englishNumberFormat = NumberFormat.getNumberInstance(Locale.US).apply {
        maximumFractionDigits = 0
    }

    private val bengaliDigits = mapOf(
        '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
        '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯'
    )

    fun formatAmount(amount: Double, language: Language, showSymbol: Boolean = true): String {
        val rounded = kotlin.math.round(amount).toLong()
        val formattedNumber = englishNumberFormat.format(rounded)
        val finalNumber = if (language == Language.BN) {
            formattedNumber.map { bengaliDigits[it] ?: it }.joinToString("")
        } else {
            formattedNumber
        }
        return if (showSymbol) "৳ $finalNumber" else finalNumber
    }

    fun toBengaliNumber(number: Int): String {
        return number.toString().map { bengaliDigits[it] ?: it }.joinToString("")
    }
}
